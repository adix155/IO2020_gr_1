<?php
/**
* Klasa służąca od wczytywania na serwer nagrań głosu do parametryzaji.
*/
class FileUpload
{
/**
* Funkcja sprawdzająca czy podczas wczytywnia pliku wystąpiły jakieś błędy i wyświetlająca adekwatny komunikat.
*
* Funkcja sprawdza czy wystąbił błąd wynikając ze zbyt dużego rozmiaru, częściowego wysłania pliku, nie wysłania pliku,
* lub innych przyczyn.
*
* @return boolean wartość logiczna true jeśli nie wystąpił żaden błąd albo false w przeciwnym wypadku.
*/
    public static function checkForUploadErrors()
    {
        if ($_FILES['recording']['error'] > 0) {
            switch ($_FILES['recording']['error']) {
                    // jest większy niż domyślny maksymalny rozmiar,
                    // podany w pliku konfiguracyjnym
                case 1: {
                        $_SESSION['max_size'] = true;
                        break;
                    }

                    // jest większy niż wartość pola formularza 
                    // MAX_FILE_SIZE
                case 2: {
                        $_SESSION['max_size'] =  true;
                        break;
                    }

                    // plik nie został wysłany w całości
                case 3: {
                        $_SESSION['part_file_send'] = true;
                        break;
                    }

                    // plik nie został wysłany
                case 4: {
                        $_SESSION['no_file_send'] = true;
                        break;
                    }

                    // pozostałe błędy
                default: {
                        $_SESSION['file_upload_error'] = true;
                        break;
                    }
            }
            return false;
        }
        return true;
    }
/**
* Funkcja sprawdzająca rozszerzenie pliku.
*
* Funkcja sprawdza czy typ pliku jest odpowiedni (.wav). 
*
* @return boolean wartość logiczna true jeśli plik jest typu .wav albo false jeśli nie jest.
*/
    public static function checkMIMEType()
    {
        if ($_FILES['recording']['type'] != 'audio/wav') {
            $_SESSION['file_type_error'] = true;
            return false;
        }
        return true;
    }

/**
* Funkcja wczytująca plik na serwer.
*
* @param integer $recordingID id nagrania które ma być wczytane, korespondujące do id pacjenta do którego to nagranie należy
* @return string nazwa właśnie wczytanego pliku.
*/
    public static function uploadFile($recordingID)
    {
        // $uploadDir = '/var/www/html/octave/recordings/';
        $uploadDir = './octave/recordings/';
        $recordingName = "rec_$recordingID.wav";
        $location = $uploadDir . $recordingName;

        if (is_uploaded_file($_FILES['recording']['tmp_name'])) {
            if (!move_uploaded_file($_FILES['recording']['tmp_name'], $location)) {
                $_SESSION['upload_failed'] = true;
                return false;
            }
        } else {
			$_SESSION['upload_failed'] = true;
            return false;
        }
        return $recordingName;
    }
}