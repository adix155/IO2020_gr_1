<?php
include_once('DBController.php');

/**
*Klasa zawieraj�ca statyczne metody do kontakt�w z tabel� u�ytkownik�w w bazie danych a tak�e do logowaniai wylogowania oraz tworzenia nowych kont.
*/
class AccountController {

/**
* Statyczna metoda s�u��ca do logowania u�ytkownika. 
*
* Metoda sprawdza istnienie u�ytkownika o podanej nazwie w bazie danych, a tak�e poprawno�� podanego has�a i w razie b�ed�w w podanych danych ustawia adekwatne flagi. W przypadku gdy dane s� poprawne
* ustawiana jest globalna zmienna, pokazuj�ca poziom uprawnie� u�ytkownika oraz ustawiana jest globalna flaga m�wi�ca, �e u�ytkownik jest zalogowany.
*
* @param string $inputUsername zsanityzowany string zawieraj�cy login u�ytkownika, kt�ry chce si� zalogowa�. Dowy�lna warto�� tego parametru to "guest"
* @param string $inputPassword zsanityzowany string zawieraj�cy has�o u�ytkownika, kt�ry chce si� zalogowa�. Dowy�lna warto�� tego parametru to "guest"
*
*/
    public static function login($inputUsername = "guest", $inputPassword = "guest") {
        $db = new DBController();
        $dbConn = $db->dbConnection;
        $queryString = "SELECT * FROM voiceparametrization.users WHERE voiceparametrization.users.username = ?";
        $queryData = $dbConn->prepare($queryString);
        $queryData->execute(array($inputUsername));
        echo $queryData->rowCount();
        if($queryData->rowCount() > 0) {
            $userData = $queryData->fetch(PDO::FETCH_ASSOC);
            if (password_verify($inputPassword, $userData["password_hash"])) {
                $_SESSION["logged_in"] = true;
                $_SESSION["user_role"] = $userData["user_role"];
                $_SESSION["user_id"] = $userData["user_ID"];
                $_SESSION["user_name"] = $userData["username"];
                $dbConn = null;
                $db = null;
                header("Location: data.php");
                return;
            } else {
                $_SESSION["invalid_password"] = true;
                header("Location: index.php");
                return;
            }
        } else {        
            $_SESSION["user_doesnt_exist"] = true;
            header("Location: index.php");
            return;
        }
    }

/**
* Statyczna metoda służąa do wylogowania użytkownika. 
*
* Metoda kończy istniejącą sesję, niszcząc wszystkie globalne zmienne i flagi a także przesyła użytkownika do ekranu logowania.
*/
    public static function logout() {
        session_unset();
        $_SESSION = array();
        session_destroy();
        header('Location: index.php');
        return;
    }

/**
* Statyczna metoda służąca do zarejestrowania nowego użytkownika. 
*
* Metoda dodaje do bazy danych użytkownika o danych podanych w parametrach.
*
* @param string $userName nazwa użytkownika, który ma być dodany do bazy danych
* @param string $userPassword hasło użytkownika, który ma być dodany do bazy danych
* @param string $userRole poziom uprawnień użytkownika, który ma być dodany do bazy danych
*/
    public static function register($userName, $userPassword, $userRole) {
        $db = new DBController();
        $dbConn = $db->dbConnection;
        $queryString = "INSERT INTO voiceparametrization.users (username, password_hash, user_role) VALUES (?, ?, ?)";
        $passwordHash = password_hash($userPassword, PASSWORD_DEFAULT);
        $queryData = $dbConn->prepare($queryString);
        $queryData->execute(array($userName, $passwordHash, $userRole));
        $dbConn = null;
        $db = null;
        return;
    }
}