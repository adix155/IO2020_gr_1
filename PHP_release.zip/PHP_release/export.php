<?php
session_start();
include("./Cryptography.php");
if(!isset($_SESSION["logged_in"])) {
    header("Location: index.php");
    die();
}

$uprawniony = false;
if(isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "Uprawniony") {
    $uprawniony = true;
}

include_once("DBController.php");
$db = new DBController();
$data = $db->readData();
$fileName = "data.csv";
$filePointer = fopen($fileName, "w");
$csvHeader = array("ID", "Imię", "Nazwisko", "Płeć", "Wiek", "CPP", "H1H2", "HRF", "NAQ", "PSP", "QOQ", "MDQ", "PS", "RDS", "RBH");
if(!$uprawniony) {
    array_splice($csvHeader, 1, 2);
}
fputcsv($filePointer, $csvHeader);
foreach ($data as $dataRow) {
    if(!$uprawniony) {
        array_splice($dataRow, 1, 2);
    } else {
        $dataRow["imie"] = Cryptography::Decrypt($dataRow["imie"]);
        $dataRow["nazwisko"] = Cryptography::Decrypt($dataRow["nazwisko"]);
    }
    $rbhData = $db->readOneRBH($dataRow["pacjent_ID"]);
    $rbhArr = array();
    foreach ($rbhData as $rbh) {
        $value = "Ekspert ". $rbh["user_ID"] . ": " . $rbh["value"];
        array_push($rbhArr, $value);
    }
    $rbhValue = implode(",", $rbhArr);
    array_push($dataRow, $rbhValue);
    fputcsv($filePointer, $dataRow);
}
fclose($filePointer);
if (file_exists($fileName)) {
    header('Content-Description: File Transfer');
    header('Content-Encoding: UTF-8');
    header('Content-type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="'.basename($fileName).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($fileName));
    echo "\xEF\xBB\xBF"; // UTF-8 BOM string
    readfile($fileName);
    exit;
}
