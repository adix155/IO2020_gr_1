$("#modal-popup").click(function() {
    $("#modal").modal("show");
})