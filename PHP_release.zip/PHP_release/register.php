<?php
// include_once("AccountController.php");
// AccountController::register("guest", "guest", "Gosć");
// AccountController::register("admin", "zaq1@WSX", "Uprawniony");
// AccountController::register("User1", "123456", "Użytkownik");
?>