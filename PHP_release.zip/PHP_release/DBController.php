<?php

/**
* Klasa służąca do łączenia się z bazą danych.
*
* Klasa zawiera metady do odczytu edycji i zapisu do bazy danych powiązanych z nagraniami głosu, takimi jak imię, nazwisko czy wiek pacjenta a także wyliczone parametry.
*/
class DBController {
/**
* Prywatna zmienna przechowująca dane do połączenia z bazą danych tj. adres serwera MySQL, nazwę bazy oraz kodowanie znaków.
*/
    private $connectionString = "mysql:host=localhost;dbname=voiceparametrization;charset=utf8";
/**
* Prywatna zmienna przechowująca login do MySQL.
*/
    private $dbUsername = "root";
/**
* Prywatna zmienna przechowująca hasło do MySQL.
*/
    private $dbPassword = "zaq1@WSX";
/**
* Publiczny obiekt klasy PDO, reprezentującej połączenie PHP z serwerem MySQL.
*/
    public $dbConnection;
/**
* Konstruktor klasy DBController inicjalizujący połączenie z bazą danych.
*/
    function __construct() {
        $this->dbConnection = new PDO($this->connectionString, $this->dbUsername, $this->dbPassword);
    }
/**
* Metoda służąca do odczytu wszystkich danych pacjentów z bazy danych. 
*
* @return $result tablica wszystkich obiektów w tabeli pacjentów.
*/
    public function readData() {
        $queryString = "SELECT * FROM voiceparametrization.parameters";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute();
        $result = $queryData->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
/**
* Metoda służąca do dodawania nowej pozycji do tabeli pacjentów z bazy danych. 
*
* Metoda dodaje do tabeli pacjentów nową pozycję, wraz z wszystkimi danymi osobistymi i ju� obliczonymi parametrami.
*
* @param mixed $insertArray tablica zawierająca dane do wpisu w następującej kolejności: imie , nazwisko , plec , wiek , CPP , H1H2 , HRF , NAQ , PSP , QOQ , MDQ , PS , RDS
*
*/
    public function addData($insertArray) {
        $queryString = "INSERT INTO voiceparametrization.parameters (imie , nazwisko , plec , wiek , CPP , H1H2 , HRF , NAQ , PSP , QOQ , MDQ , PS , RDS) VALUES (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute($insertArray);
        return;
    }
/**
* Metoda służąca do edytowania pozycji w tabeli pacjentów z bazy danych. 
*
* Metoda pozwala edytować imię, nazwisko oraz skalę rbh pacjenta o podanym id.
*
* @param $patientNameSurname string zawierający nowe imię i nazwisko, rozdzielone spacjami 
* @param $rbhScale string zawierający nową skalę RBH
* @param $patientID id pacjenta, który ma być edytowany
*
*/
    public function editData($patientNameSurname, $patientID) {
        $patientData = explode(" ", $patientNameSurname);
        $patientName = $patientData[0];
        $patientSurname = $patientData[1];
        $queryString = "UPDATE voiceparametrization.parameters SET imie = ? , nazwisko = ?  WHERE pacjent_ID = ?";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute(array($patientName, $patientSurname, $patientID));
        return;
    }
/**
* Metoda służąca do usunięcia pozycji w tabeli pacjentów z bazy danych. 
*
* Metoda pozwala usunąć pozycję pacjenta o podanym id z bazy danych.
*
* @param integer $patientID id pacjenta, który ma być usunięty
*
*/
    public function deleteData($patientID) {
        $queryString = "DELETE FROM voiceparametrization.parameters WHERE pacjent_ID = ?";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute(array($patientID));
        return;
    }

/**
* Metoda służąca do odczytu jednej, konkretniej pozycji z tabeli pacjentów z bazy danych. 
*
* Metoda pozwala odczytać pozycję pacjenta o podanym id z bazy danych.
*
* @param integer $patientID id pacjenta, który ma być odczytany
* @return mixed $result tablica wszystkich obiektów w tabeli pacjentów.
*/
    public function readOne($patientID) {

        $queryString = "SELECT * FROM voiceparametrization.parameters WHERE pacjent_ID = ?";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute(array($patientID));
        $result = $queryData->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

/**
* Metoda służąca do uzyskania ostatniej wartości auto inkrementującego się klucza podstawowego z tabeli pacjentów. 
*
* @return string $result ostatnia wartość klucza podstawowego (pacjent_ID)
*/
    public function getLastRecordingId() {
        $queryString = "SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_name = 'parameters' AND table_schema = 'voiceparametrization'";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute();
        $result = $queryData->fetch();
        return $result;
    }


/**
 * Metoda dodająca skalę RBH do bazy danych.
 * 
 * @param integer $userId id użytkownika, który dodał skalę RBH
 * @param integer $recordingId id nagrania, które jest powiązane ze skalą
 * @param string $value wartość skali RBH
 */

    public function addRBH($userId, $recordingId, $value) {
        $queryString = "INSERT INTO `voiceparametrization`.`rbh` (`user_ID`, `recording_ID`, `value`) VALUES (? , ? , ?)";
        $queryData = $this->dbConnection->prepare($queryString);
        $queryData->execute(array($userId, $recordingId, $value));
        return;
    }

    /**
     * Metoda pobierająca z bazy wartości skali RBH powiązane z danym pacjentem
     * 
     * @param integer $recordingId id nagrania, które jest powiązane ze skalą
     * 
     * @return mixed $result dane z bazy, które zawierają informacje o skali RBH dla danego nagrania
     */

        public function readOneRBH($recordingId) {
            $queryString = "SELECT `voiceparametrization`.`rbh`.`user_ID` , `voiceparametrization`.`rbh`.`value` FROM `voiceparametrization`.`parameters` JOIN `voiceparametrization`.`rbh` ON `voiceparametrization`.`parameters`.`pacjent_ID` = `voiceparametrization`.`rbh`.`recording_ID` WHERE `voiceparametrization`.`parameters`.`pacjent_ID` = ? ORDER BY `voiceparametrization`.`rbh`.`user_ID` ASC";
            $queryData = $this->dbConnection->prepare($queryString);
            $queryData->execute(array($recordingId));
            $result = $queryData->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        }


        /**
         * Metoda edytująca wartość skali RBH dla danego użytkownika
         * 
         * @param string $value wartość skali RBH
         * @param integer $recordingId wartość id nagrania, dla którego edytujemy skalę RBH
         * @param integer $userId wartość id użytkownika, który edytował skalę RBH
         */

         public function editRBH($value, $recordingId, $userId) {
            $queryString = "UPDATE `voiceparametrization`.`rbh` SET `value` = ? WHERE `recording_ID` = ? AND `user_ID` = ?";
            $queryData = $this->dbConnection->prepare($queryString);
            $queryData->execute(array($value, $recordingId, $userId));
            return;
         }
         /**
          * Metoda usuwająca wartość RBH dla danego nagrania
          *
          *@param integer $recordingId wartość id nagrania, dla którego usuwamy skalę RBH
          */
          public function deleteRBH($recordingId) {
            $queryString = "DELETE FROM `voiceparametrization`.`rbh` WHERE recording_ID = ?";
            $queryData = $this->dbConnection->prepare($queryString);
            $queryData->execute(array($recordingId));
            return;
          }
}
