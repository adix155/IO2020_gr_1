<?php
/**
 * Klasa służąca do porozumienia się z programem Octave
 */
class OctaveController {
    /**
     * Metoda służąca do wywołania funkcji w programie Octave w celu wykonania parametryzacji głosu
     * 
     * @param string $recordingPath ścieżka do nagrania, dla którego wykonana zostanie parametryzacja
     * @param integer $insertingID id nowego nagrania
     */
    public static function getVoiceParams($recordingPath, $insertingID) {
        // chdir("/var/www/html/octave/functions"); -- ścieżka pod linuxa
        chdir("./octave/functions"); // -- ścieżka pod Windowsa
        exec("octave-cli Covarep_testing.m ../recordings/rec_$insertingID.wav $insertingID");
        $tempFilename = "temp-params_$insertingID.csv";
        $csvFileHandle = fopen($tempFilename, "r");
        $csvParameters = fgets($csvFileHandle);
        $parameters = explode(",", $csvParameters);
        fclose($csvFileHandle);
        unlink($tempFilename);
        chdir("../..");
        return $parameters;
    }
}
